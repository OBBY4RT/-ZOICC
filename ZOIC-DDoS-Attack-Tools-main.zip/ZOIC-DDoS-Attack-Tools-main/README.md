# ZOIC - DDoS Attack Tools 🔥
- **version 3.0 ✅**

# ZOIC - Tutorial 🔥

**Link : https://github.com/user-attachments/assets/838a7a43-e8a6-4f26-a3db-48fadf2454b8**

# ScreenShot📷:
![image](https://github.com/user-attachments/assets/95497f6c-9954-469a-a75b-cde236f27ec2)

# LAYER 4 🔥
![image](https://github.com/user-attachments/assets/e8a17a43-9072-4e9e-9adb-13ae3e88ad70)
![image](https://github.com/user-attachments/assets/1600edc0-8c5c-4782-a23f-381637c712ec)
![image](https://github.com/user-attachments/assets/942ec2bc-197b-43c9-bd88-6f334fc13ef2)



# LAYER 7 🔥
![image](https://github.com/user-attachments/assets/e0921fc3-0407-4b41-8f50-0c90716dfe4b)
![image](https://github.com/user-attachments/assets/d95ec7e5-35f1-4b7b-b04a-c7eb603f2f82)
![image](https://github.com/user-attachments/assets/6a697ebe-d5a3-4c04-bef0-7fcd8421cd52)



# HOW TO USE ❓
```
git clone https://github.com/madanokr001/ZOIC-DDoS-Attack-Tools.git
```
```
cd ZOIC-DDoS-Attack-Tools
```
```
ls
```
```
python setup.py
```
```
cd ZOIC
```
```
python main.py
```

## WINDOWS ✅
## LINUX ✅ 

# About 🤑
**We greatly appreciate your feedback and suggestions. Please feel free to share any thoughts you may have; your input is invaluable to us!**






